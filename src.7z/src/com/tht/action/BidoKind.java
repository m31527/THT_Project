package com.tht.action;

import java.util.HashMap;

public class BidoKind {
	
	public static HashMap<Integer, String> list=new HashMap<Integer, String>();
	
	static {
		list.put(1401, "瑤池金母");

		list.put(1402, "王母娘娘");

		list.put(1403, "玉皇上帝");

		list.put(1404, "三官大帝");

		list.put(1405, "紫微大地");

		list.put(1406, "斗父");

		list.put(1407, "斗母");

		list.put(1408, "東斗護命");

		list.put(1409, "西斗護命");

		list.put(1410, "中斗保命");

		list.put(1411, "南斗延壽");

		list.put(1412, "東華帝君");

		list.put(1413, "太上道組");

		list.put(1414, "南極仙翁");

		list.put(1415, "驪山老母");

		list.put(1416, "中壇元帥");

		list.put(1417, "關聖帝君");

		list.put(1418, "孚佑帝君");

		list.put(1419, "天王 君");

		list.put(1420, "九天命司");

		list.put(1421, "陳靖姑元君");

		list.put(1422, "彌勒古佛");

		list.put(1423, "釋迦牟尼佛");

		list.put(1424, "藥師琉璃佛");

		list.put(1425, "觀世音菩薩");

		list.put(1426, "普賢菩薩");

		list.put(1427, "地藏王菩薩");

		list.put(1428, "文殊菩薩");

		list.put(1429, "九天玄女");

		list.put(1430, "玄天上帝");

		list.put(1431, "文昌帝君");

		list.put(1432, "張府天師");

		list.put(1433, "註生娘娘");

		list.put(1434, "月老星君");

		list.put(1435, "濟公禪師");

		list.put(1436, "齊天大聖");

		list.put(1437, "二郎神君");

		list.put(1438, "善財童子");

		list.put(1439, "福德正神");

		list.put(1440, "五路財神");

		list.put(1441, "平安斗");

	}

}
